--
-- PostgreSQL database dump
--

-- Dumped from database version 12.20 (Ubuntu 12.20-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 16.3

-- Started on 2024-10-11 10:42:41

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 6 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- TOC entry 2998 (class 0 OID 0)
-- Dependencies: 6
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 633 (class 1247 OID 16398)
-- Name: logtype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.logtype AS ENUM (
    'use',
    'distribute',
    'issue'
);


--
-- TOC entry 545 (class 1247 OID 16390)
-- Name: role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.role AS ENUM (
    'super_admin',
    'department_admin',
    'department_member',
    'guest'
);


--
-- TOC entry 657 (class 1247 OID 16804)
-- Name: usetype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.usetype AS ENUM (
    'text_to_image',
    'image_to_image',
    'inpainting',
    'remove_background',
    'clip',
    'clean_up',
    'training'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 203 (class 1259 OID 16595)
-- Name: department; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.department (
    department_id integer NOT NULL,
    name character varying(255) NOT NULL
);


--
-- TOC entry 202 (class 1259 OID 16593)
-- Name: department_department_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.department_department_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2999 (class 0 OID 0)
-- Dependencies: 202
-- Name: department_department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.department_department_id_seq OWNED BY public.department.department_id;


--
-- TOC entry 205 (class 1259 OID 16603)
-- Name: member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member (
    member_id integer NOT NULL,
    login_id character varying(50) NOT NULL,
    password character varying NOT NULL,
    name character varying(100) NOT NULL,
    nickname character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    role public.role NOT NULL,
    token_quantity integer NOT NULL,
    create_date timestamp without time zone NOT NULL,
    department_id integer
);


--
-- TOC entry 204 (class 1259 OID 16601)
-- Name: member_member_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3000 (class 0 OID 0)
-- Dependencies: 204
-- Name: member_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_member_id_seq OWNED BY public.member.member_id;


--
-- TOC entry 207 (class 1259 OID 16749)
-- Name: token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.token (
    token_id integer NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    origin_quantity integer NOT NULL,
    remain_quantity integer NOT NULL,
    is_active boolean NOT NULL,
    department_id integer
);


--
-- TOC entry 209 (class 1259 OID 16763)
-- Name: token_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.token_log (
    log_id integer NOT NULL,
    create_date timestamp without time zone NOT NULL,
    log_type public.logtype NOT NULL,
    use_type public.usetype,
    quantity integer,
    image_quantity integer,
    model character varying(255),
    member_id integer,
    department_id integer
);


--
-- TOC entry 208 (class 1259 OID 16761)
-- Name: token_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.token_log_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3001 (class 0 OID 0)
-- Dependencies: 208
-- Name: token_log_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.token_log_log_id_seq OWNED BY public.token_log.log_id;


--
-- TOC entry 206 (class 1259 OID 16747)
-- Name: token_token_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.token_token_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3002 (class 0 OID 0)
-- Dependencies: 206
-- Name: token_token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.token_token_id_seq OWNED BY public.token.token_id;


--
-- TOC entry 211 (class 1259 OID 16781)
-- Name: token_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.token_usage (
    usage_id integer NOT NULL,
    quantity integer NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    member_id integer,
    token_id integer
);


--
-- TOC entry 210 (class 1259 OID 16779)
-- Name: token_usage_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.token_usage_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3003 (class 0 OID 0)
-- Dependencies: 210
-- Name: token_usage_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.token_usage_usage_id_seq OWNED BY public.token_usage.usage_id;


--
-- TOC entry 2830 (class 2604 OID 16598)
-- Name: department department_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.department ALTER COLUMN department_id SET DEFAULT nextval('public.department_department_id_seq'::regclass);


--
-- TOC entry 2831 (class 2604 OID 16606)
-- Name: member member_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member ALTER COLUMN member_id SET DEFAULT nextval('public.member_member_id_seq'::regclass);


--
-- TOC entry 2832 (class 2604 OID 16752)
-- Name: token token_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token ALTER COLUMN token_id SET DEFAULT nextval('public.token_token_id_seq'::regclass);


--
-- TOC entry 2833 (class 2604 OID 16766)
-- Name: token_log log_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_log ALTER COLUMN log_id SET DEFAULT nextval('public.token_log_log_id_seq'::regclass);


--
-- TOC entry 2834 (class 2604 OID 16784)
-- Name: token_usage usage_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_usage ALTER COLUMN usage_id SET DEFAULT nextval('public.token_usage_usage_id_seq'::regclass);


--
-- TOC entry 2984 (class 0 OID 16595)
-- Dependencies: 203
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.department (department_id, name) FROM stdin;
1	인사팀
2	개발팀
3	운영팀
\.


--
-- TOC entry 2986 (class 0 OID 16603)
-- Dependencies: 205
-- Data for Name: member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member (member_id, login_id, password, name, nickname, email, role, token_quantity, create_date, department_id) FROM stdin;
2	dev1	$2b$12$SRVw7zsXfvZIXAKT501wRu9Qmusl37LIPKh0UU/L9HbEAUvW/RH7O	개발부장	김싸피	dev1@example.com	department_admin	987129	2024-09-11 22:50:31.061465	2
6	hr2	$2b$12$SRVw7zsXfvZIXAKT501wRu9Qmusl37LIPKh0UU/L9HbEAUvW/RH7O	인사담당자2	hr2nick	hr2@example.com	department_member	400	2024-09-11 22:50:31.061465	1
7	hr3	$2b$12$SRVw7zsXfvZIXAKT501wRu9Qmusl37LIPKh0UU/L9HbEAUvW/RH7O	인사담당자3	hr3nick	hr3@example.com	department_member	300	2024-09-11 22:50:31.061465	1
9	op2	$2b$12$SRVw7zsXfvZIXAKT501wRu9Qmusl37LIPKh0UU/L9HbEAUvW/RH7O	운영담당자2	op2nick	op2@example.com	department_member	500	2024-09-11 22:50:31.061465	3
10	op3	$2b$12$SRVw7zsXfvZIXAKT501wRu9Qmusl37LIPKh0UU/L9HbEAUvW/RH7O	운영담당자3	op3nick	op3@example.com	department_member	400	2024-09-11 22:50:31.061465	3
5	hr1	$2b$12$SRVw7zsXfvZIXAKT501wRu9Qmusl37LIPKh0UU/L9HbEAUvW/RH7O	인사부장	hr1nick	hr1@example.com	department_admin	493	2024-09-11 22:50:31.061465	1
3	dev2	$2b$12$SRVw7zsXfvZIXAKT501wRu9Qmusl37LIPKh0UU/L9HbEAUvW/RH7O	개발자2	dev2nick	dev2@example.com	department_member	13080	2024-09-11 22:50:31.061465	2
8	op1	$2b$12$SRVw7zsXfvZIXAKT501wRu9Qmusl37LIPKh0UU/L9HbEAUvW/RH7O	운영부장	op1nick	op1@example.com	department_admin	700	2024-09-11 22:50:31.061465	3
4	dev3	$2b$12$SRVw7zsXfvZIXAKT501wRu9Qmusl37LIPKh0UU/L9HbEAUvW/RH7O	개발자3	dev3nick	dev3@example.com	department_member	14390	2024-09-11 22:50:31.061465	2
1	admin	$2b$12$bfZr3E5tEyoSRFS6u60DUO6o1Uj42ds4TPYGz/eo/QTUgL.sPrFP.	슈퍼 관리자	Admin	user@example.com	super_admin	18799	2024-09-11 22:50:31.061465	1
\.


--
-- TOC entry 2988 (class 0 OID 16749)
-- Dependencies: 207
-- Data for Name: token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.token (token_id, start_date, end_date, origin_quantity, remain_quantity, is_active, department_id) FROM stdin;
3	2024-09-11 22:50:31.061465	2024-10-11 22:50:31.061465	1000	300	t	3
6	2024-09-12 00:07:52.148196	2024-10-02 23:59:59	300	300	t	3
8	2024-09-12 08:06:58.004222	2024-10-12 23:59:59	100	80	t	2
9	2024-09-12 08:06:58.024979	2024-10-12 23:59:59	100	100	t	3
11	2024-09-13 01:08:46.801258	2024-10-02 23:59:59	100	100	t	1
12	2024-09-13 01:08:46.825938	2024-10-02 23:59:59	100	100	t	3
15	2024-09-13 01:45:41.300496	2025-01-01 23:59:59	120	120	t	3
16	2024-09-13 03:00:03.459314	2024-09-26 23:59:59	200	200	t	1
17	2024-09-16 12:04:28.431142	2024-09-26 23:59:59	11000	11000	t	2
18	2024-09-16 12:04:28.461196	2024-09-26 23:59:59	11000	11000	t	3
13	2024-09-13 01:45:41.258963	2025-01-01 23:59:59	120	0	t	2
1	2024-09-11 22:50:31.061465	2024-10-11 22:50:31.061465	1000	0	t	1
19	2024-09-27 05:34:27.584702	2024-09-27 05:34:14.164	20000	20000	t	1
20	2024-09-27 05:34:38.075419	2024-10-27 05:34:14.164	20000	0	t	1
4	2024-09-12 00:07:52.104318	2024-10-02 23:59:59	300	280	f	2
5	2024-09-12 00:07:52.126004	2024-10-02 23:59:59	300	150	f	1
10	2024-09-13 01:08:46.772976	2024-10-02 23:59:59	100	96	f	2
21	2024-10-08 05:25:25.708352	2024-10-08 23:59:59	10	10	t	1
22	2024-10-08 05:25:25.735671	2024-10-08 23:59:59	10	10	t	2
23	2024-10-08 05:25:25.759362	2024-10-08 23:59:59	10	10	t	3
25	2024-10-08 07:01:41.087195	2024-10-31 23:59:59	100000	100000	t	1
26	2024-10-08 07:01:41.110982	2024-10-31 23:59:59	100000	100000	t	3
24	2024-10-08 07:01:41.063551	2024-10-31 23:59:59	100000	58000	t	2
2	2024-09-11 22:50:31.061465	2024-10-11 22:50:31.061465	1000	280	t	2
7	2024-09-12 08:06:57.977415	2024-10-12 23:59:59	100	89	t	1
14	2024-09-13 01:45:41.279381	2025-01-01 23:59:59	120	10	t	1
27	2024-10-08 07:34:58.768137	2024-10-08 23:59:59	100	100	t	1
28	2024-10-10 00:21:48.211672	2024-10-31 23:59:59	1000000	0	t	2
\.


--
-- TOC entry 2990 (class 0 OID 16763)
-- Dependencies: 209
-- Data for Name: token_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.token_log (log_id, create_date, log_type, use_type, quantity, image_quantity, model, member_id, department_id) FROM stdin;
50	2024-09-25 15:34:14.913565	use	image_to_image	1	1	stable-diffusion-2	1	1
60	2024-09-26 03:17:12.671609	use	image_to_image	1	1	stable-diffusion-2	1	1
66	2024-09-26 06:41:39.489397	use	clip	1	1	ViT-L-14/openai	1	1
67	2024-09-26 07:04:04.917461	distribute	\N	150	\N	\N	1	1
68	2024-09-26 07:04:20.16719	distribute	\N	80	\N	\N	1	2
1	2024-09-18 15:56:58.686382	use	text_to_image	50	50	\N	1	1
2	2024-09-17 15:56:58.686382	use	remove_background	60	60	\N	1	1
3	2024-09-16 15:56:58.686382	use	clip	30	30	\N	1	1
4	2024-09-15 15:56:58.686382	distribute	\N	100	100	\N	1	1
5	2024-09-14 15:56:58.686382	use	clean_up	50	50	\N	1	1
6	2024-09-13 15:56:58.686382	use	text_to_image	80	80	\N	1	1
7	2024-09-12 15:56:58.686382	distribute	\N	120	120	\N	1	1
8	2024-09-11 15:56:58.686382	issue	\N	300	300	\N	1	1
9	2024-09-10 15:56:58.686382	use	remove_background	20	20	\N	1	1
10	2024-09-09 15:56:58.686382	use	text_to_image	70	70	\N	1	1
11	2024-09-08 15:56:58.686382	use	clip	40	40	\N	1	1
12	2024-09-07 15:56:58.686382	issue	\N	200	200	\N	1	1
13	2024-09-06 15:56:58.686382	use	clean_up	60	60	\N	1	1
14	2024-09-05 15:56:58.686382	distribute	\N	250	250	\N	1	1
15	2024-09-04 15:56:58.686382	use	clip	50	50	\N	1	1
16	2024-09-03 15:56:58.686382	use	text_to_image	30	30	\N	1	1
17	2024-09-02 15:56:58.686382	distribute	\N	200	200	\N	1	1
18	2024-09-01 15:56:58.686382	use	clean_up	40	40	\N	1	1
19	2024-08-31 15:56:58.686382	use	remove_background	60	60	\N	1	1
20	2024-08-30 15:56:58.686382	use	clip	70	70	\N	1	1
21	2024-08-29 15:56:58.686382	issue	\N	300	300	\N	1	1
22	2024-08-28 15:56:58.686382	use	clean_up	50	50	\N	1	1
23	2024-09-25 06:14:50.826604	use	text_to_image	30	30	stable-diffusion-2	1	1
51	2024-09-25 15:36:44.075926	use	inpainting	3	3	stable-diffusion-2-inpainting	1	1
56	2024-09-25 17:43:32.321535	use	remove_background	3	3	briaai/RMBG-1.4	1	1
61	2024-09-26 03:18:25.55215	use	inpainting	9	9	stable-diffusion-2-inpainting	1	1
96	2024-09-27 13:22:16.792799	use	clean_up	1	1	lama	1	1
97	2024-09-27 13:22:33.91022	use	clip	1	1	ViT-L-14/openai	1	1
113	2024-09-30 13:03:16.755203	use	clip	1	1	ViT-L-14/openai	1	1
123	2024-10-04 14:12:10.618057	use	training	1200	1200	custom_model123	1	1
95	2024-09-27 13:18:43.271544	use	remove_background	6	6	briaai/RMBG-1.4	1	1
92	2024-09-27 07:35:13.410922	use	inpainting	44	44	stable-diffusion-2-inpainting	1	1
125	2024-10-05 01:45:41.386363	use	training	5320	5320	sss	1	1
111	2024-09-30 01:18:31.913713	use	image_to_image	13	13	stable-diffusion-2	1	1
110	2024-09-30 01:14:13.181262	use	text_to_image	33	33	stable-diffusion-2	1	1
114	2024-10-01 07:04:11.771806	use	text_to_image	2	2	stable-diffusion-2	1	1
109	2024-09-29 07:43:21.136345	use	text_to_image	36	36	stable-diffusion-2	1	1
115	2024-10-01 07:37:30.517471	use	image_to_image	11	11	stable-diffusion-2	1	1
99	2024-09-28 13:05:43.505823	use	inpainting	18	18	stable-diffusion-2-inpainting	1	1
127	2024-10-05 02:25:36.237424	use	training	1100	1100	dd	1	1
108	2024-09-29 07:09:22.347727	use	inpainting	25	25	stable-diffusion-2-inpainting	1	1
100	2024-09-28 13:34:57.164981	use	image_to_image	3	3	stable-diffusion-2	1	1
93	2024-09-27 08:24:15.463775	use	inpainting	32	32	cable_vent	1	1
105	2024-09-29 01:48:32.792752	use	image_to_image	58	58	stable-diffusion-2	1	1
101	2024-09-28 13:54:57.393953	use	remove_background	4	4	briaai/RMBG-1.4	1	1
88	2024-09-27 05:33:40.971703	distribute	\N	900	\N	\N	1	1
89	2024-09-27 05:34:27.598693	issue	\N	20000	\N	\N	1	1
90	2024-09-27 05:34:38.089365	issue	\N	20000	\N	\N	1	1
91	2024-09-27 05:35:16.774709	distribute	\N	20000	\N	\N	1	1
106	2024-09-29 02:45:03.214453	use	remove_background	20	20	briaai/RMBG-1.4	1	1
102	2024-09-28 14:11:44.077253	use	clean_up	3	3	lama	1	1
98	2024-09-28 03:56:48.236752	use	text_to_image	66	66	stable-diffusion-2	1	1
103	2024-09-28 23:34:00.805234	use	clip	1	1	ViT-L-14/openai	1	1
104	2024-09-29 00:47:59.999019	use	clip	4	4	ViT-L-14/openai	1	1
69	2024-09-26 07:21:18.371892	use	text_to_image	40	40	stable-diffusion-2	1	1
86	2024-09-26 08:55:22.965732	use	text_to_image	43	43	stable-diffusion-2	1	1
87	2024-09-27 00:28:39.663469	use	text_to_image	3114	3114	stable-diffusion-2	1	1
116	2024-10-02 04:34:33.32039	use	text_to_image	5	5	stable-diffusion-2	1	1
94	2024-09-27 12:56:41.769353	use	image_to_image	5	5	stable-diffusion-2	1	1
117	2024-10-02 07:24:10.354293	use	image_to_image	15	15	stable-diffusion-2	1	1
107	2024-09-29 02:47:33.8431	use	clean_up	1	1	lama	1	1
122	2024-10-04 11:33:10.754917	use	training	5270	5270	custom_model	1	1
128	2024-10-05 03:40:19.87799	use	training	2080	2080	ww	1	1
129	2024-10-05 03:45:44.242727	use	training	2200	2200	www	1	1
118	2024-10-04 00:31:10.113781	use	training	8082	8082	garam_test	1	1
112	2024-09-30 07:48:09.809428	use	inpainting	2	2	stable-diffusion-2-inpainting	1	1
130	2024-10-05 03:55:07.210176	use	training	2080	2080	qq	1	1
124	2024-10-05 00:33:25.577549	use	training	9340	9340	custom_model	1	1
121	2024-10-04 08:58:04.427643	use	clip	1	1	ViT-L-14/openai	1	1
120	2024-10-04 08:47:27.964247	use	inpainting	56	56	stable-diffusion-2-inpainting	1	1
119	2024-10-04 08:40:59.4866	use	text_to_image	26	26	stable-diffusion-2	1	1
134	2024-10-05 04:42:18.645678	use	inpainting	3	3	1/first_train	1	1
126	2024-10-05 02:14:56.41494	use	training	2080	2080	a	1	1
133	2024-10-05 04:39:40.991888	use	inpainting	34	34	stable-diffusion-2-inpainting	1	1
132	2024-10-05 04:15:03.801566	use	training	2040	2040	s	1	1
136	2024-10-05 05:05:16.575318	use	image_to_image	29	29	stable-diffusion-2	1	1
135	2024-10-05 04:43:00.538937	use	training	1020	1020	test1	1	1
137	2024-10-05 05:12:25.354852	use	text_to_image	1	1	stable-diffusion-2	1	1
131	2024-10-05 04:01:20.720125	use	training	7110	7110	ss	1	1
138	2024-10-05 05:19:11.384778	use	image_to_image	41	41	stable-diffusion-v1-5	1	1
139	2024-10-05 06:10:21.715014	use	inpainting	3	3	1/cable-defect-model	1	1
140	2024-10-05 06:13:04.047563	use	inpainting	122	122	1/hazelnut-defect-model	1	1
141	2024-10-05 15:12:23.085732	use	training	4080	4080	test	1	1
143	2024-10-05 15:52:11.975674	use	training	1020	1020	1model	1	1
142	2024-10-05 15:26:28.532267	use	training	11220	11220	aa	1	1
144	2024-10-05 15:52:45.654888	use	training	2040	2040	2model	1	1
145	2024-10-05 15:57:46.82479	use	training	6120	6120	4model	1	1
146	2024-10-05 16:10:41.646233	use	training	1020	1020	mmmmmmmmmmmm	1	1
147	2024-10-05 16:17:58.558614	use	training	1020	1020	po	1	1
148	2024-10-05 16:19:09.955241	use	training	1020	1020	ttttt11	1	1
149	2024-10-05 16:19:13.647402	use	training	1020	1020	u	1	1
150	2024-10-05 16:22:27.267379	use	training	1020	1020	uuuu	1	1
155	2024-10-05 16:41:30.236823	use	training	1020	1020	rrr	1	1
157	2024-10-05 16:42:14.361299	use	training	1020	1020	rrrrrr	1	1
158	2024-10-05 16:47:24.945757	use	training	1020	1020	testing	1	1
160	2024-10-05 16:52:04.554536	use	training	1020	1020	ttt1	1	1
161	2024-10-05 16:55:35.540493	use	training	1020	1020	ttt1dd1122	1	1
162	2024-10-05 16:55:50.663078	use	training	1020	1020	ttt1dd11	1	1
163	2024-10-05 16:56:12.975524	use	training	1020	1020	ttt1dd112233444	1	1
166	2024-10-05 16:58:22.696902	use	training	1020	1020	ttt1dd11223344455	1	1
168	2024-10-05 17:00:30.50351	use	training	1020	1020	ttt1dd11223344455677	1	1
169	2024-10-05 17:00:49.707772	use	training	1020	1020	ttt1dd112233444556778899111	1	1
171	2024-10-05 17:01:01.823627	use	training	1020	1020	ttt1dd11223344455677889911133322	1	1
172	2024-10-05 17:01:08.959431	use	training	1020	1020	ttt1dd112233444556778899	1	1
174	2024-10-05 17:02:09.179925	use	training	1020	1020	ttt1dd112233444556778899111333223	1	1
176	2024-10-05 17:02:47.249848	use	training	1020	1020	ttt1dd112233444556778899111333223455	1	1
177	2024-10-05 17:03:36.494987	use	training	1010	1010	ttt1dd1122334456677	1	1
181	2024-10-05 17:04:51.790524	use	training	1010	1010	a1	1	1
151	2024-10-05 16:22:31.204898	use	training	1020	1020	uuuuuu	1	1
152	2024-10-05 16:31:09.993905	use	training	1020	1020	nnn	1	1
153	2024-10-05 16:40:59.435166	use	training	1020	1020	rr	1	1
154	2024-10-05 16:41:22.561581	use	training	1020	1020	r	1	1
156	2024-10-05 16:41:36.111671	use	training	1020	1020	rrrr	1	1
159	2024-10-05 16:49:35.834957	use	training	1002	1002	jjhtest1	1	1
164	2024-10-05 16:56:18.693794	use	training	1020	1020	ttt1dd112233	1	1
165	2024-10-05 16:58:07.693197	use	training	1020	1020	ttt1dd112233444556	1	1
167	2024-10-05 17:00:11.369436	use	training	1020	1020	ttt1dd1122334445567788	1	1
170	2024-10-05 17:00:58.727166	use	training	1020	1020	ttt1dd112233444556778899111333	1	1
173	2024-10-05 17:01:51.039729	use	training	1020	1020	ttt1dd1122334445567788991113332234	1	1
175	2024-10-05 17:02:30.153451	use	training	1020	1020	ttt1dd11223344455677889911133322345566	1	1
178	2024-10-05 17:03:41.587584	use	training	1010	1010	ttt1dd1122334445567788991113332234556677	1	1
179	2024-10-05 17:04:45.59018	use	training	1010	1010	a3	1	1
180	2024-10-05 17:04:45.695501	use	training	1010	1010	a2	1	1
182	2024-10-05 17:14:29.555792	use	training	1010	1010	dsafaSDasfd	1	1
183	2024-10-05 17:14:37.652878	use	training	1010	1010	dsafaSD	1	1
184	2024-10-05 17:16:01.198213	use	training	1010	1010	dsafaSDasfdss	1	1
185	2024-10-05 17:16:14.253031	use	training	1010	1010	dsafaSDasfdssasda	1	1
186	2024-10-05 17:16:35.418719	use	training	1010	1010	dsafaSDasfdssasdasf	1	1
187	2024-10-05 17:16:42.440552	use	training	2030	2030	dsafaSDasfdssasdasfsdf	1	1
188	2024-10-05 17:17:16.826659	use	training	1020	1020	dsafaSDasfdssasdasfsdfsdf	1	1
189	2024-10-05 17:18:17.721213	use	training	1040	1040	dsafaSDasfdssasdasfsdfsdfss	1	1
207	2024-10-07 02:43:54.920472	use	training	1010	1010	qa	1	1
190	2024-10-05 17:18:24.866762	use	training	3120	3120	dsafaSDasfdssasdasfsdfsdfsssdf	1	1
191	2024-10-05 17:23:21.720872	use	training	1040	1040	dsafaSDasfdssasdasfsdfsdfsssdfaaa	1	1
192	2024-10-05 17:24:55.989513	use	training	2080	2080	dsafaSDasfdssasdasfsdfsdfsssdfaaaaa	1	1
193	2024-10-05 17:26:22.298466	use	training	1040	1040	dsafaSDasfdssasdasfsdfsdfsssdfaaaaaaa	1	1
250	2024-10-08 07:34:08.119689	use	training	1010	1010	model	1	1
242	2024-10-08 07:01:41.076059	issue	\N	100000	\N	\N	1	2
243	2024-10-08 07:01:41.100927	issue	\N	100000	\N	\N	1	1
244	2024-10-08 07:01:41.120956	issue	\N	100000	\N	\N	1	3
208	2024-10-07 02:44:55.052766	use	training	6060	6060	qaw	1	1
209	2024-10-07 03:08:39.152649	use	training	1010	1010	qaws	1	1
210	2024-10-07 03:11:10.535024	use	training	2020	2020	qawss	1	1
211	2024-10-07 03:17:12.636326	use	training	2020	2020	qawssy	1	1
245	2024-10-08 07:02:56.302995	distribute	\N	42000	\N	\N	2	2
227	2024-10-08 05:21:46.474349	use	image_to_image	1	1	stable-diffusion-v1-5	1	1
225	2024-10-08 02:07:37.974838	use	text_to_image	46	46	stable-diffusion-v1-5	1	1
212	2024-10-07 06:12:14.40252	use	text_to_image	1	1	stable-diffusion-v1-5	1	1
213	2024-10-07 06:13:43.020041	use	inpainting	1	1	1/metal_nut_model_1	1	1
214	2024-10-07 06:15:58.622502	use	training	1020	1020	eddd	1	1
228	2024-10-08 05:22:27.41185	use	inpainting	1	1	stable-diffusion-2-inpainting	1	1
215	2024-10-07 07:05:08.156045	use	training	1020	1020	dsfa	1	1
216	2024-10-07 07:05:39.446943	use	training	2040	2040	dsfaadas	1	1
195	2024-10-06 10:30:44.152319	use	image_to_image	7	7	stable-diffusion-2	1	1
229	2024-10-08 05:25:25.723336	issue	\N	10	\N	\N	1	1
230	2024-10-08 05:25:25.748055	issue	\N	10	\N	\N	1	2
217	2024-10-07 07:21:27.550904	use	text_to_image	1	1	stable-diffusion-v1-5	5	1
231	2024-10-08 05:25:25.772437	issue	\N	10	\N	\N	1	3
233	2024-10-08 05:29:58.799747	use	image_to_image	3	3	stable-diffusion-v1-4	2	2
196	2024-10-07 00:00:06.523503	use	text_to_image	4122	4122	stable-diffusion-2	1	1
194	2024-10-06 05:10:44.307687	use	text_to_image	2561	2561	stable-diffusion-2	1	1
197	2024-10-07 02:23:08.328251	use	training	2040	2040	qrr	1	1
198	2024-10-07 02:23:33.531158	use	training	1020	1020	qrrfs	1	1
199	2024-10-07 02:23:44.629455	use	training	1020	1020	qrrf	1	1
201	2024-10-07 02:24:43.112347	use	training	1010	1010	qrrfsd	1	1
234	2024-10-08 05:31:55.274916	use	inpainting	5	5	stable-diffusion-2-inpainting	2	2
251	2024-10-08 07:34:58.781475	issue	\N	100	\N	\N	1	1
200	2024-10-07 02:24:32.972452	use	training	5050	5050	qrrfsdk	1	1
218	2024-10-07 15:11:02.285371	use	clean_up	5	5	lama	1	1
202	2024-10-07 02:33:48.08622	use	training	1010	1010	qrrfsdkdd	1	1
203	2024-10-07 02:34:21.072514	use	training	2020	2020	qrrfsdkddgg	1	1
204	2024-10-07 02:41:14.792769	use	training	1010	1010	qrrfsdkddggww	1	1
205	2024-10-07 02:41:42.868143	use	training	1010	1010	qrrfsdkddggwwd	1	1
206	2024-10-07 02:42:42.04163	use	training	2020	2020	q	1	1
219	2024-10-07 16:46:03.528234	use	clip	1	1	ViT-L-14/openai	1	1
220	2024-10-07 23:58:21.104858	use	text_to_image	2	2	stable-diffusion-2	5	1
221	2024-10-08 00:03:33.463848	use	text_to_image	3	3	stable-diffusion-v1-5	5	1
222	2024-10-08 00:04:36.808787	use	image_to_image	1	1	stable-diffusion-2	5	1
232	2024-10-08 05:28:16.202042	use	text_to_image	6	6	stable-diffusion-v1-5	2	2
238	2024-10-08 06:01:25.916164	use	clip	1	1	ViT-L-14/openai	2	2
226	2024-10-08 02:56:06.837769	use	clip	18	18	ViT-L-14/openai	1	1
246	2024-10-08 07:09:38.787172	distribute	\N	500	\N	\N	2	2
236	2024-10-08 05:51:46.578045	use	text_to_image	5	5	stable-diffusion-2	2	2
241	2024-10-08 06:37:07.064291	use	remove_background	1	1	briaai/RMBG-1.4	2	2
235	2024-10-08 05:34:03.44431	use	clean_up	2	2	lama	2	2
239	2024-10-08 06:01:42.644827	use	image_to_image	20	20	stable-diffusion-2	2	2
247	2024-10-08 07:12:36.452864	distribute	\N	11	\N	\N	1	1
248	2024-10-08 07:13:31.004132	distribute	\N	110	\N	\N	1	1
224	2024-10-08 00:15:35.002985	use	image_to_image	36	36	stable-diffusion-2	1	1
237	2024-10-08 05:54:40.76783	use	inpainting	23	23	1/cable_vent	1	1
240	2024-10-08 06:09:24.724108	use	clean_up	8	8	lama	1	1
249	2024-10-08 07:32:28.573979	use	remove_background	9	9	briaai/RMBG-1.4	1	1
254	2024-10-08 11:29:05.98361	use	training	1020	1020	test1	1	1
255	2024-10-08 11:30:35.134125	use	training	1020	1020	test3	1	1
253	2024-10-08 11:29:00.821251	use	training	2040	2040	test2	1	1
256	2024-10-08 11:37:04.915215	use	training	1020	1020	test4	1	1
257	2024-10-08 11:38:33.095994	use	training	1020	1020	test6	1	1
258	2024-10-08 11:38:36.344778	use	training	1020	1020	test5	1	1
259	2024-10-08 11:38:56.432688	use	training	1020	1020	test8	1	1
260	2024-10-08 11:39:12.533364	use	training	1020	1020	test7	1	1
261	2024-10-08 11:40:10.852046	use	training	1020	1020	test10	1	1
262	2024-10-08 11:47:18.770517	use	training	1020	1020	test12	1	1
223	2024-10-08 00:09:23.533388	use	text_to_image	17	17	stable-diffusion-2	1	1
263	2024-10-08 11:47:29.848178	use	training	1020	1020	test11	1	1
265	2024-10-08 11:52:05.103593	use	training	1020	1020	model14	1	1
266	2024-10-08 11:52:27.381768	use	training	1020	1020	model13	1	1
269	2024-10-08 11:59:16.636079	use	training	1020	1020	model17	1	1
272	2024-10-08 12:10:45.295812	use	training	1020	1020	model20	1	1
288	2024-10-09 06:14:45.311265	use	clip	4	4	ViT-L-14/openai	1	1
286	2024-10-09 06:00:26.755739	use	inpainting	73	73	1/hazelnut-defect-model	1	1
282	2024-10-09 05:56:07.724448	use	clean_up	14	14	lama	1	1
264	2024-10-08 11:48:17.892496	use	training	1020	1020	test14	1	1
267	2024-10-08 11:53:02.018871	use	training	1020	1020	model16	1	1
268	2024-10-08 11:54:48.269721	use	training	1020	1020	model15	1	1
271	2024-10-08 11:59:48.37233	use	training	1020	1020	model18	1	1
270	2024-10-08 11:59:32.915971	use	training	2040	2040	model19	1	1
274	2024-10-08 12:11:58.098967	use	training	1020	1020	model21	1	1
298	2024-10-09 09:50:10.673149	use	inpainting	1	1	1/metal_nut_model_1	1	1
297	2024-10-09 09:46:31.304808	use	training	2400	2400	adsf	1	1
275	2024-10-08 12:12:51.956594	use	training	1020	1020	model23	1	1
273	2024-10-08 12:11:35.948857	use	training	4080	4080	model22	1	1
308	2024-10-09 13:22:53.204432	use	training	3000	3000	crack-phone	2	2
252	2024-10-08 08:39:54.89556	use	training	13028	13028	garam_test	1	1
276	2024-10-08 23:36:04.455412	use	training	2100	2100	models1	1	1
277	2024-10-08 23:53:45.274748	use	training	1050	1050	models2	1	1
299	2024-10-09 10:11:24.636997	use	inpainting	2	2	1/screw-defect-model	1	1
325	2024-10-10 00:18:34.316305	use	clean_up	2	2	lama	1	1
312	2024-10-09 15:46:08.285807	use	inpainting	4	4	stable-diffusion-2-inpainting	2	2
279	2024-10-09 05:38:51.691403	use	text_to_image	32	32	stable-diffusion-2	1	1
336	2024-10-10 06:42:09.214087	use	inpainting	10	10	2/scrated model1	2	2
287	2024-10-09 06:00:52.659909	use	inpainting	8	8	1/cable_vent	1	1
337	2024-10-10 06:42:57.968472	use	inpainting	10	10	2/scratched-phone8	2	2
339	2024-10-10 06:43:30.580011	use	inpainting	10	10	2/cracked-phone3	2	2
319	2024-10-09 18:07:50.164979	use	training	3000	3000	cracked-phone3	2	2
284	2024-10-09 05:59:32.987159	use	inpainting	24	24	1/cable-defect-model	1	1
313	2024-10-09 16:41:19.959039	use	inpainting	114	114	1/scratch_model	1	1
346	2024-10-10 08:22:56.957449	use	training	1350	1350	crack smartphone	3	2
300	2024-10-09 10:52:06.417207	use	inpainting	12	12	1/crack	1	1
301	2024-10-09 11:03:52.498693	use	training	1050	1050	crack4	1	1
289	2024-10-09 06:15:23.949155	use	image_to_image	13	13	stable-diffusion-2	1	1
290	2024-10-09 07:03:10.481514	use	image_to_image	1	1	stable-diffusion-v1-5	1	1
302	2024-10-09 11:11:37.692199	use	training	1050	1050	crack7	1	1
320	2024-10-10 00:00:23.191586	use	inpainting	331	331	2/crack-phone2	2	2
314	2024-10-09 16:59:10.498815	use	training	1500	1500	crack-phone2	2	2
349	2024-10-10 23:57:01.791112	use	training	1500	1500	scratced model 13	2	2
303	2024-10-09 11:28:02.599586	use	training	3030	3030	uus	1	1
331	2024-10-10 00:25:39.789195	use	inpainting	100	100	2/crack-phone	2	2
304	2024-10-09 11:32:26.987042	use	training	1010	1010	cat	1	1
335	2024-10-10 06:29:39.294704	use	inpainting	19	19	1/leather-defect-model	1	1
283	2024-10-09 05:58:22.370437	use	inpainting	70	70	stable-diffusion-2-inpainting	1	1
291	2024-10-09 07:52:06.993703	use	text_to_image	4	4	stable-diffusion-v1-4	1	1
278	2024-10-09 05:31:07.129061	use	remove_background	44	44	briaai/RMBG-1.4	1	1
315	2024-10-09 17:16:21.667744	use	inpainting	14	14	1/scratch_model_2	1	1
310	2024-10-09 13:42:45.137631	use	remove_background	29	29	briaai/RMBG-1.4	2	2
281	2024-10-09 05:52:07.619378	use	text_to_image	1030	1030	stable-diffusion-v1-5	1	1
311	2024-10-09 13:43:34.063418	use	clean_up	6	6	lama	2	2
285	2024-10-09 05:59:53.465468	use	inpainting	53	53	1/metal_nut_model_2	1	1
292	2024-10-09 07:54:41.950778	use	training	4800	4800	model11111	1	1
350	2024-10-11 00:47:36.909261	use	text_to_image	6	6	stable-diffusion-v1-4	1	1
305	2024-10-09 13:00:58.22787	use	training	2120	2120	t1	1	1
309	2024-10-09 13:41:03.817528	use	inpainting	291	291	2/crack-phone	2	2
280	2024-10-09 05:47:33.159412	use	text_to_image	3	3	stable-diffusion-2	2	2
294	2024-10-09 09:08:47.016476	use	clip	1	1	ViT-L-14/openai	2	2
295	2024-10-09 09:09:10.692112	use	image_to_image	1	1	stable-diffusion-2	2	2
296	2024-10-09 09:24:50.5021	use	training	2400	2400	ff	2	2
293	2024-10-09 08:43:41.928593	use	text_to_image	2	2	stable-diffusion-v1-5	2	2
306	2024-10-09 13:08:38.598028	use	training	1040	1040	dsaf	2	2
321	2024-10-10 00:02:25.813231	use	text_to_image	1	1	stable-diffusion-v1-5	2	2
322	2024-10-10 00:09:00.505867	use	text_to_image	1	1	stable-diffusion-2	1	1
307	2024-10-09 13:11:30.130412	use	training	2080	2080	ih	2	2
332	2024-10-10 03:49:23.23249	use	inpainting	19	19	stable-diffusion-2-inpainting	1	1
317	2024-10-09 17:49:50.419988	use	training	1500	1500	scratched phone	2	2
323	2024-10-10 00:12:19.521232	use	inpainting	2	2	1/cable_vent	1	1
340	2024-10-10 06:48:36.921193	use	training	1500	1500	small_scratch_phone	2	2
318	2024-10-09 17:50:43.187363	use	inpainting	15	15	2/scratched phone	2	2
327	2024-10-10 00:21:48.225557	issue	\N	1000000	\N	\N	1	2
329	2024-10-10 00:22:17.169813	distribute	\N	1000000	\N	\N	1	2
316	2024-10-09 17:32:11.706261	use	inpainting	105	105	2/crack-phone2	2	2
343	2024-10-10 07:28:15.338842	use	inpainting	15	15	2/grid_model	2	2
345	2024-10-10 08:15:55.863875	use	inpainting	70	70	2/logo_print_fail_phone	2	2
347	2024-10-10 09:45:40.508242	use	training	1500	1500	model1	2	2
348	2024-10-10 09:56:23.214328	use	training	3000	3000	cracked model 10	2	2
344	2024-10-10 08:12:39.56328	use	training	1500	1500	logo_print_fail_phone	2	2
333	2024-10-10 06:18:00.594946	use	inpainting	6	6	1/metal_nut_model_2	1	1
324	2024-10-10 00:17:48.209666	use	remove_background	5	5	briaai/RMBG-1.4	1	1
334	2024-10-10 06:18:28.88813	use	inpainting	6	6	1/metal_nut_model_1	1	1
338	2024-10-10 06:43:24.770993	use	inpainting	54	54	1/capsule-defect-model	1	1
341	2024-10-10 06:52:15.434966	use	inpainting	50	50	2/small_scratch_phone	2	2
342	2024-10-10 07:20:48.858169	use	training	1500	1500	scrated model1	2	2
352	2024-10-11 00:48:58.253246	use	text_to_image	18	18	stable-diffusion-2	1	1
326	2024-10-10 00:20:53.976956	use	remove_background	76	76	briaai/RMBG-1.4	2	2
328	2024-10-10 00:22:02.581856	use	inpainting	218	218	1/hazelnut-defect-model	1	1
351	2024-10-11 00:48:47.510528	use	text_to_image	8	8	stable-diffusion-v1-5	1	1
330	2024-10-10 00:23:22.240101	use	clean_up	34	34	lama	2	2
354	2024-10-11 01:03:20.862845	use	image_to_image	6	6	stable-diffusion-v1-4	1	1
355	2024-10-11 01:04:31.013757	use	image_to_image	6	6	stable-diffusion-v1-5	1	1
356	2024-10-11 01:05:10.783722	use	image_to_image	6	6	stable-diffusion-2	1	1
358	2024-10-11 01:07:15.387501	use	inpainting	123	123	2/crack-phone2	2	2
359	2024-10-11 01:10:04.771335	use	inpainting	12	12	stable-diffusion-2-inpainting	1	1
360	2024-10-11 01:11:49.114811	use	inpainting	20	20	2/scratched-phone8	2	2
361	2024-10-11 01:13:00.761576	use	inpainting	10	10	2/cracked model11	2	2
357	2024-10-11 01:06:34.542742	use	clean_up	3	3	lama	2	2
362	2024-10-11 01:13:00.875882	use	training	1500	1500	scratced model 14	2	2
353	2024-10-11 00:54:49.206391	use	remove_background	17	17	briaai/RMBG-1.4	2	2
363	2024-10-11 01:17:28.247093	use	inpainting	10	10	2/scratced model 13	2	2
364	2024-10-11 01:23:31.070867	use	inpainting	1	1	stable-diffusion-2-inpainting	2	2
\.


--
-- TOC entry 2992 (class 0 OID 16781)
-- Dependencies: 211
-- Data for Name: token_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.token_usage (usage_id, quantity, start_date, end_date, member_id, token_id) FROM stdin;
3	20	2024-09-11 22:50:31.061465	2024-09-13 22:50:31.061465	4	2
5	15	2024-09-11 22:50:31.061465	2024-09-12 22:50:31.061465	6	3
9	60	2024-09-07 22:53:55.905247	2024-09-16 22:53:55.905247	4	2
10	250	2024-09-06 22:53:55.905247	2024-09-17 22:53:55.905247	5	2
11	50	2024-09-05 22:53:55.905247	2024-09-18 22:53:55.905247	6	2
13	70	2024-09-03 22:53:55.905247	2024-09-20 22:53:55.905247	7	3
14	180	2024-09-02 22:53:55.905247	2024-09-21 22:53:55.905247	8	3
15	100	2024-09-01 22:53:55.905247	2024-09-22 22:53:55.905247	9	3
16	90	2024-08-31 22:53:55.905247	2024-09-23 22:53:55.905247	10	3
17	80	2024-08-30 22:53:55.905247	2024-09-24 22:53:55.905247	9	3
20	30	2024-09-08 22:54:30.194846	2024-09-14 22:54:30.194846	4	1
21	100	2024-09-07 22:54:30.194846	2024-09-15 22:54:30.194846	5	2
22	80	2024-09-06 22:54:30.194846	2024-09-16 22:54:30.194846	6	2
23	120	2024-09-05 22:54:30.194846	2024-09-17 22:54:30.194846	7	3
24	300	2024-09-04 22:54:30.194846	2024-09-18 22:54:30.194846	8	3
25	200	2024-09-03 22:54:30.194846	2024-09-19 22:54:30.194846	9	3
58	12845	2024-10-08 07:01:41.063551	2024-10-31 23:59:59	3	24
64	987129	2024-10-10 00:21:48.211672	2024-10-31 23:59:59	2	28
28	90	2024-08-31 22:54:30.194846	2024-09-22 22:54:30.194846	4	2
29	30	2024-08-30 22:54:30.194846	2024-09-23 22:54:30.194846	5	2
30	60	2024-08-29 22:54:30.194846	2024-09-24 22:54:30.194846	6	3
31	80	2024-08-28 22:54:30.194846	2024-09-25 22:54:30.194846	7	3
32	100	2024-08-27 22:54:30.194846	2024-09-26 22:54:30.194846	8	3
33	120	2024-08-26 22:54:30.194846	2024-09-27 22:54:30.194846	9	3
34	100	2024-09-11 22:50:31.061465	2024-10-11 22:50:31.061465	8	3
35	100	2024-09-11 22:50:31.061465	2024-10-11 22:50:31.061465	9	3
36	100	2024-09-11 22:50:31.061465	2024-10-11 22:50:31.061465	10	3
37	100	2024-09-11 22:50:31.061465	2024-10-11 22:50:31.061465	8	3
39	10	2024-09-12 08:06:58.004222	2024-10-12 23:59:59	4	8
40	10	2024-09-12 08:06:58.004222	2024-10-12 23:59:59	4	8
42	10	2024-09-11 22:50:31.061465	2024-10-11 22:50:31.061465	4	2
43	10	2024-09-13 01:45:41.258963	2025-01-01 23:59:59	3	13
44	10	2024-09-13 01:45:41.258963	2025-01-01 23:59:59	4	13
45	10	2024-09-13 01:45:41.258963	2025-01-01 23:59:59	3	13
46	10	2024-09-13 01:45:41.258963	2025-01-01 23:59:59	4	13
57	18098	2024-09-27 05:34:38.075419	2024-10-27 05:34:14.164	1	20
4	3	2024-09-11 22:50:31.061465	2024-09-14 22:50:31.061465	5	2
59	14000	2024-10-08 07:01:41.063551	2024-10-31 23:59:59	4	24
62	11	2024-09-12 08:06:57.977415	2024-10-12 23:59:59	1	7
63	110	2024-09-13 01:45:41.279381	2025-01-01 23:59:59	1	14
54	40	2024-09-13 01:45:41.258963	2025-01-01 23:59:59	4	13
\.


--
-- TOC entry 3004 (class 0 OID 0)
-- Dependencies: 202
-- Name: department_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.department_department_id_seq', 3, true);


--
-- TOC entry 3005 (class 0 OID 0)
-- Dependencies: 204
-- Name: member_member_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_member_id_seq', 22, true);


--
-- TOC entry 3006 (class 0 OID 0)
-- Dependencies: 208
-- Name: token_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.token_log_log_id_seq', 364, true);


--
-- TOC entry 3007 (class 0 OID 0)
-- Dependencies: 206
-- Name: token_token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.token_token_id_seq', 28, true);


--
-- TOC entry 3008 (class 0 OID 0)
-- Dependencies: 210
-- Name: token_usage_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.token_usage_usage_id_seq', 64, true);


--
-- TOC entry 2836 (class 2606 OID 16600)
-- Name: department department_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_pkey PRIMARY KEY (department_id);


--
-- TOC entry 2838 (class 2606 OID 16613)
-- Name: member member_login_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_login_id_key UNIQUE (login_id);


--
-- TOC entry 2840 (class 2606 OID 16615)
-- Name: member member_nickname_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_nickname_key UNIQUE (nickname);


--
-- TOC entry 2842 (class 2606 OID 16611)
-- Name: member member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (member_id);


--
-- TOC entry 2847 (class 2606 OID 16768)
-- Name: token_log token_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_log
    ADD CONSTRAINT token_log_pkey PRIMARY KEY (log_id);


--
-- TOC entry 2845 (class 2606 OID 16754)
-- Name: token token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token
    ADD CONSTRAINT token_pkey PRIMARY KEY (token_id);


--
-- TOC entry 2850 (class 2606 OID 16786)
-- Name: token_usage token_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_usage
    ADD CONSTRAINT token_usage_pkey PRIMARY KEY (usage_id);


--
-- TOC entry 2843 (class 1259 OID 16760)
-- Name: ix_end_date_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_end_date_is_active ON public.token USING btree (end_date, is_active);


--
-- TOC entry 2848 (class 1259 OID 16797)
-- Name: ix_member_id_end_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_member_id_end_date ON public.token_usage USING btree (member_id, end_date);


--
-- TOC entry 2851 (class 2606 OID 16616)
-- Name: member member_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.department(department_id);


--
-- TOC entry 2852 (class 2606 OID 16755)
-- Name: token token_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token
    ADD CONSTRAINT token_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.department(department_id);


--
-- TOC entry 2853 (class 2606 OID 16774)
-- Name: token_log token_log_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_log
    ADD CONSTRAINT token_log_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.department(department_id);


--
-- TOC entry 2854 (class 2606 OID 16769)
-- Name: token_log token_log_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_log
    ADD CONSTRAINT token_log_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member(member_id);


--
-- TOC entry 2855 (class 2606 OID 16787)
-- Name: token_usage token_usage_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_usage
    ADD CONSTRAINT token_usage_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member(member_id);


--
-- TOC entry 2856 (class 2606 OID 16792)
-- Name: token_usage token_usage_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.token_usage
    ADD CONSTRAINT token_usage_token_id_fkey FOREIGN KEY (token_id) REFERENCES public.token(token_id);


-- Completed on 2024-10-11 10:42:42

--
-- PostgreSQL database dump complete
--

